function [bestEEG] = select_eeg(varargin)
%SELECT EEG compares eegs by making power spectrums from a scan file and selects the best one 
%   Takes in all eegs from scan file
%   Outputs bestEEG
%   1. find a way to exclude eegs with an snr of under 3


SD=gss;%grab all scan datasets 
for ii=1:length(SD.selData)
    data = evalin('base', SD.selData{ii}); %load current data set into work space
    SNR = [];
    for jj = 1:length(data.trials(5).eeg)
        SNR(jj) = eeg_powerspec(data.trials(5).eeg(jj).eeg,250) % shouldn't be trial 5 but generalized to find the sleep trial 
    end
    bestSNR = find(max(SNR))%this finds the index for the eeg with the best SNR 

end

